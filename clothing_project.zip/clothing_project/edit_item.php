<?php
// Start of the PHP file
include 'db_connect.php'; // Ensure this file exists and is correctly referenced

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input
    $id = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT);
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $category = filter_input(INPUT_POST, 'category', FILTER_SANITIZE_STRING);
    $quantity = filter_input(INPUT_POST, 'quantity', FILTER_SANITIZE_NUMBER_INT);

    // Check if ID is valid
    if (empty($id) || !is_numeric($id)) {
        echo "Invalid ID provided.";
        exit();
    }

    // Debugging: Check the values received
    // var_dump($id, $name, $category, $quantity); // Uncomment for debugging

    // Prepare the SQL statement
    $stmt = $conn->prepare("UPDATE inventory SET name=?, category=?, quantity=? WHERE id=?");
    $stmt->bind_param("ssii", $name, $category, $quantity, $id);

    // Execute the statement
    if ($stmt->execute()) {
        // Redirect to index.php after successful update
        header("Location: index.php?message=Item updated successfully");
        exit();
    } else {
        // Log the error and show a user-friendly message
        error_log("Error updating item: " . $stmt->error);
        echo "Error updating item. Please try again.";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>