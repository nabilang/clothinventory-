<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clothing Inventory Management</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Clothing Inventory Management</h1>
    </header>
    
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
         
            <li><a href="add.html">Add Item</a></li>
        </ul>
    </nav>
    
    <main>
        <section>
            <h2>Welcome to the Clothing Inventory Management System</h2>
            <p>Manage your clothing stock efficiently.</p>
        </section>
        
        <section>
            <h2>Inventory Overview</h2>
            <table>
                <thead>
                    <tr>
                        <th>Item ID</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include 'db_connect.php';
                    $result = mysqli_query($conn, "SELECT * FROM inventory");
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['name'] . "</td>";
                        echo "<td>" . $row['category'] . "</td>";
                        echo "<td>" . $row['quantity'] . "</td>";
                        echo "<td><a href='edit.html?id=" . $row['id'] . "'>Edit</a> | <a href='delete.php?id=" . $row['id'] . "'>Delete</a></td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </section>
    </main>
    
    <footer>
        <p>&copy; 2025 Clothing Inventory System</p>
    </footer>
</body>
</html>